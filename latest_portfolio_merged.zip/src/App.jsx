import { Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import LogisticMapLesson from "./lessons/LogisticMapLesson";
import TaylorSeriesLesson from "./lessons/TaylorSeriesLesson";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/lessons/logistic-map" element={<LogisticMapLesson />} />
      <Route path="/lessons/taylor-series" element={<TaylorSeriesLesson />} />
    </Routes>
  );
}
